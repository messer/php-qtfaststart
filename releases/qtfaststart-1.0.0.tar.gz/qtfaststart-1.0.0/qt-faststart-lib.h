int do_faststart(char *in, char *out);

